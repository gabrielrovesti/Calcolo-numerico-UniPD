A=[1 10^-5 -2*10^-10 -2*10^-5 10^-5;
    -10^-7 1+10^-14 -10^-7 10^7 10^7;
    10^-10 -1 10^-10 10^-10 10^10];

% Aggiungo due colonne in più per contenere gli errori relativi da
% calcolare

% Per ogni riga k
    % Fornisco i coefficienti e le x conosciute allo script
    % eseguo lo script
    % calcolo gli errori relativi
    % e li inserisco nell'array

% mostro i risultati ottenuti