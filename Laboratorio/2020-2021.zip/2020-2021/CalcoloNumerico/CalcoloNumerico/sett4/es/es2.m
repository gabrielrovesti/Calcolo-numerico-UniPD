% Definire le successioni u_n, z_n, y_n

% Calcolo delle successioni

% Calcolo degli errori assoluti

% Grafico
