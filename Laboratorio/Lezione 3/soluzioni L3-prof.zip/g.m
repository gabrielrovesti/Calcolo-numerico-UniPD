function y=g(x)
y=exp(1).^x./(x.^2+1);