clear all
load testvar
[yourx yourr yourres]=MinNormLs(myA,myb,1e-12);
fprintf('difference of computed solutions is %g\n', norm(yourx-myx))
fprintf('difference of computed residual is %g\n', abs(yourres-myres))
fprintf('computed rank is %d\n',yourr)
fprintf('matlab rank is %d\n',rank(myA))
