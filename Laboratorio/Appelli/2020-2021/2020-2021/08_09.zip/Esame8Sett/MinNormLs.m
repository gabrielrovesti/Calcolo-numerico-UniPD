function [x, r, res] = MinNormLs(A, b, toll)
%MINNORMLS Calcola il vettore soluzione di norma minima
%   Alessio Ferrarini 1223860
%   A: matrice nxn
%   b: vettore colonna noto lungo n
%   toll: precisione richiesta
%   x: soluzione di norma minima
%   r: rango di A
%   res: norma del residuo delle equazioni normali
    
    % Se impostata a true esegue la function usando
    % la funzione rank e la risoluzione dei sitemi tramite
    % backslash
    test = false;

    % Punto 1
    [Q R P] = qr(A');
    
    % Punto 2
    if test
        r = rank(A);
    else
        r = sum(abs(diag(R)) >= length(A) * toll);
    end
    
    % Punto 3
    R0 = R(1:r, :);
    Q0 = Q(:,   1:r);
    S  = R0 * R0';
    
    % Punto 4
    if test
        y = S \ (R0 * b);
    else
        [L, U, P] = lu(S);
        y  = L \ (P * R0 * b);
        ys = U \ y;
    end
    
    % Punto 5
    x = Q0 * ys;
    res = norm(A' * A * x - A' * b);
end

