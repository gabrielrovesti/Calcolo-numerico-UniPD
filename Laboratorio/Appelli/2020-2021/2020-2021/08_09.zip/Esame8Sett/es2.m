% Alessio Ferrarrini 1223860

samp = 3:30;

rec_cond = samp;

res_al = samp;
res_mat = samp;

norm_al = samp;
norm_mat = samp;

for n = samp
    
    index = n - 2;
    
    % Punto 1
    A0 = hilb(n);
    A_pass = A0(1:(n - 1), :);
    A = [ A_pass ; sum(A_pass) ];
    
    onez = ones(n, 1);
    b = A * onez;
    
    % Punto 2
    rec_cond(index) = rcond(A);
    
    % Punto 3
    toll = 1e-9;
    [x, r, res] = MinNormLs(A, b, toll);
    
    C = A' * A;
    d = A' * b;
    x_matlab = lsqminnorm(C, d, toll);
    
    % Punto 4
    norm_al(index) = norm(x);
    norm_mat(index) = norm(x_matlab);
    
    res_al(index) = res;
    res_mat(index) = norm(C * x_matlab - d);
end

semilogy(norm_al);
hold on;
semilogy(norm_mat);
title("Norme");
legend("Norma MinNormLs", "Norma lsqminnorm");
hold off;

figure(2);
semilogy(rec_cond);
hold on;
semilogy(res_al);
semilogy(res_mat);
title("Residui + cond");
legend("Reciproco condizionamento", "Residuo MinNormLs", ...
       "Residuo lsqmminnorm");

fprintf(1, "Il metodo non è stabile in quanto esso utilizza al suo interno operazioni non stabili di persè");