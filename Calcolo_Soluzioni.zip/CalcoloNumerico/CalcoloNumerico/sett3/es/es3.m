clear;

% Come es1